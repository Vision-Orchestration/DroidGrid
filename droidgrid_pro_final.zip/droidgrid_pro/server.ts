/**
 * DroidGrid Pro — Express backend
 */
import express, { Request, Response } from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import os from "os";
import http from "http";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR      = path.join(os.homedir(), ".droidgrid");
const PROFILES_FILE = path.join(DATA_DIR, "profiles.json");
const CAMERAS_FILE  = path.join(DATA_DIR, "cameras.json");
const SESSION_FILE  = path.join(DATA_DIR, "session.json");
fs.mkdirSync(DATA_DIR, { recursive: true });

function readJson<T>(file: string, fallback: T): T {
  try { if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, "utf8")); } catch {}
  return fallback;
}
function writeJson(file: string, data: unknown) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

interface Camera {
  id: string; name: string; ip: string; port: number;
  res: [number, number]; fps: number; enabled: boolean;
  status: "online"|"offline"|"checking"|"recording";
}
interface Profile {
  id: string; name: string; cameras: Camera[];
  session: SessionState; createdAt: string;
}
interface SessionState {
  label: string; person: string; repeat: string;
  pattern: string; recordDir: string; snapDir: string;
}
interface LogEntry {
  id: number; time: string; system: string; msg: string;
  level: "info"|"warn"|"error"|"success";
}

let cameras: Camera[] = readJson<Camera[]>(CAMERAS_FILE, [
  { id:"cam-1", name:"Phone-1", ip:"192.168.137.101", port:4747, res:[1280,720], fps:30, enabled:true,  status:"offline" },
  { id:"cam-2", name:"Phone-2", ip:"192.168.137.102", port:4747, res:[1280,720], fps:30, enabled:true,  status:"offline" },
  { id:"cam-3", name:"Phone-3", ip:"192.168.137.103", port:4747, res:[1280,720], fps:30, enabled:false, status:"offline" },
]);
let profiles: Record<string, Profile> = readJson(PROFILES_FILE, {});
let lastProfileId: string|null = null;
let session: SessionState = readJson<SessionState>(SESSION_FILE, {
  label:"session", person:"p01", repeat:"r01",
  pattern:"{label}_{person}_{repeat}_{camera}",
  recordDir:"recordings", snapDir:"snapshots",
});
let isRecording = false;
let recordingStartTime: number|null = null;
let logCounter = 1;
const logs: LogEntry[] = [];

function addLog(system: string, msg: string, level: LogEntry["level"] = "info") {
  const entry: LogEntry = {
    id: logCounter++,
    time: new Date().toLocaleTimeString("en-GB", {hour:"2-digit",minute:"2-digit",second:"2-digit"}),
    system, msg, level,
  };
  logs.unshift(entry);
  if (logs.length > 200) logs.pop();
  return entry;
}

async function checkCamera(cam: Camera): Promise<boolean> {
  return new Promise((resolve) => {
    const req = http.get(`http://${cam.ip}:${cam.port}/mjpegfeed`, {timeout:3000}, (res) => {
      res.destroy();
      resolve((res.statusCode ?? 0) < 500);
    });
    req.on("error", () => resolve(false));
    req.on("timeout", () => { req.destroy(); resolve(false); });
  });
}

async function checkAllCameras() {
  addLog("SCAN", `Checking ${cameras.filter(c=>c.enabled).length} enabled cameras...`);
  await Promise.all(cameras.map(async (cam) => {
    if (!cam.enabled) return;
    cam.status = "checking";
    const ok = await checkCamera(cam);
    cam.status = ok ? "online" : "offline";
    addLog("CAMERA", `${cam.name} (${cam.ip}) — ${ok?"ONLINE":"offline"}`, ok?"success":"warn");
  }));
  writeJson(CAMERAS_FILE, cameras);
}

addLog("SERVER", "DroidGrid Pro backend started", "success");
setTimeout(checkAllCameras, 1500);
setInterval(checkAllCameras, 30000);

async function startServer() {
  const app = express();
  const PORT = 3000;
  app.use(express.json());

  app.get("/api/health", (_req,res) => res.json({
    status:"ok", version:"2.4.0-pro", uptime:process.uptime(),
    cameras:cameras.length, online:cameras.filter(c=>c.status==="online").length,
    recording:isRecording,
  }));

  // ── Cameras ──────────────────────────────────────────────────────────────
  app.get("/api/cameras", (_req,res) => res.json(cameras));

  app.post("/api/cameras", (req,res) => {
    const cam: Camera = {
      id:`cam-${Date.now()}`, name:req.body.name||"New Camera",
      ip:req.body.ip||"", port:req.body.port||4747,
      res:req.body.res||[1280,720], fps:req.body.fps||30,
      enabled:true, status:"offline",
    };
    cameras.push(cam);
    writeJson(CAMERAS_FILE, cameras);
    addLog("CONFIG", `Added: ${cam.name} (${cam.ip})`, "success");
    res.json(cam);
  });

  app.put("/api/cameras/:id", (req,res) => {
    const idx = cameras.findIndex(c=>c.id===req.params.id);
    if (idx===-1) { res.status(404).json({error:"Not found"}); return; }
    cameras[idx] = {...cameras[idx], ...req.body};
    writeJson(CAMERAS_FILE, cameras);
    res.json(cameras[idx]);
  });

  app.delete("/api/cameras/:id", (req,res) => {
    const idx = cameras.findIndex(c=>c.id===req.params.id);
    if (idx===-1) { res.status(404).json({error:"Not found"}); return; }
    const name = cameras[idx].name;
    cameras.splice(idx,1);
    writeJson(CAMERAS_FILE, cameras);
    addLog("CONFIG", `Removed: ${name}`, "warn");
    res.json({ok:true});
  });

  app.post("/api/cameras/:id/test", async (req,res) => {
    const cam = cameras.find(c=>c.id===req.params.id);
    if (!cam) { res.status(404).json({error:"Not found"}); return; }
    cam.status = "checking";
    addLog("TEST", `Testing ${cam.name} (${cam.ip}:${cam.port})...`);
    const ok = await checkCamera(cam);
    cam.status = ok?"online":"offline";
    writeJson(CAMERAS_FILE, cameras);
    addLog("TEST", `${cam.name} — ${ok?"ONLINE":"offline"}`, ok?"success":"warn");
    res.json({id:cam.id, status:cam.status});
  });

  app.post("/api/cameras/test-all", async (_req,res) => {
    await checkAllCameras();
    res.json({cameras: cameras.map(c=>({id:c.id,name:c.name,status:c.status}))});
  });

  // ── Recording ─────────────────────────────────────────────────────────────
  app.post("/api/recording/start", (_req,res) => {
    if (isRecording) { res.json({ok:false,msg:"Already recording"}); return; }
    const online = cameras.filter(c=>c.enabled&&c.status==="online");
    if (!online.length) { addLog("REC","Start failed — no cameras online","error"); res.json({ok:false,msg:"No cameras online"}); return; }
    isRecording = true;
    recordingStartTime = Date.now();
    online.forEach(c=>{ c.status="recording"; });
    writeJson(CAMERAS_FILE, cameras);
    addLog("REC",`Started: ${session.label}/${session.person}/${session.repeat} (${online.length} cams)`,"success");
    res.json({ok:true, cameras:online.length, session:{...session}});
  });

  app.post("/api/recording/stop", (_req,res) => {
    if (!isRecording) { res.json({ok:false,msg:"Not recording"}); return; }
    const duration = recordingStartTime ? Math.round((Date.now()-recordingStartTime)/1000) : 0;
    isRecording = false;
    recordingStartTime = null;
    cameras.forEach(c=>{ if(c.status==="recording") c.status="online"; });
    writeJson(CAMERAS_FILE, cameras);
    try {
      const n = parseInt(session.repeat.replace(/\D/g,""),10)+1;
      session.repeat = `r${String(n).padStart(2,"0")}`;
      writeJson(SESSION_FILE, session);
    } catch {}
    addLog("REC",`Stopped after ${duration}s → ${session.recordDir}/`,"success");
    res.json({ok:true, duration, newRepeat:session.repeat});
  });

  app.get("/api/recording/status", (_req,res) => {
    const elapsed = isRecording&&recordingStartTime ? Math.round((Date.now()-recordingStartTime)/1000) : 0;
    res.json({recording:isRecording, elapsed, session});
  });

  app.post("/api/snapshot", (_req,res) => {
    const online = cameras.filter(c=>c.enabled&&(c.status==="online"||c.status==="recording"));
    if (!online.length) { addLog("SNAP","Snapshot failed — no cameras online","error"); res.json({ok:false,msg:"No cameras online"}); return; }
    const ts = new Date().toISOString().slice(0,19).replace(/[T:]/g,"-");
    const files = online.map(c=>{
      let name = session.pattern;
      const tokens: Record<string,string> = {
        label:session.label, person:session.person, repeat:session.repeat,
        camera:c.name, date:ts.slice(0,10), time:ts.slice(11),
      };
      Object.entries(tokens).forEach(([k,v])=>{ name=name.replace(`{${k}}`,v); });
      return `${session.snapDir}/${name}_${ts}.jpg`;
    });
    addLog("SNAP",`Saved ${files.length} snapshot(s) to ${session.snapDir}/`,"success");
    res.json({ok:true, files});
  });

  // ── Session ───────────────────────────────────────────────────────────────
  app.get("/api/session", (_req,res) => res.json(session));
  app.put("/api/session", (req,res) => {
    session = {...session,...req.body};
    writeJson(SESSION_FILE, session);
    addLog("SESSION",`Updated: ${session.label}/${session.person}/${session.repeat}`);
    res.json(session);
  });

  // ── Profiles ──────────────────────────────────────────────────────────────
  app.get("/api/profiles", (_req,res) => res.json({profiles:Object.values(profiles),lastUsed:lastProfileId}));

  app.post("/api/profiles", (req,res) => {
    const id = `profile-${Date.now()}`;
    const profile: Profile = {
      id, name:req.body.name||"Unnamed Profile",
      cameras:JSON.parse(JSON.stringify(cameras)),
      session:JSON.parse(JSON.stringify(session)),
      createdAt:new Date().toISOString(),
    };
    profiles[id] = profile;
    lastProfileId = id;
    writeJson(PROFILES_FILE, profiles);
    addLog("PROFILE",`Saved: "${profile.name}"`,"success");
    res.json(profile);
  });

  app.put("/api/profiles/:id", (req,res) => {
    if (!profiles[req.params.id]) { res.status(404).json({error:"Not found"}); return; }
    profiles[req.params.id] = {...profiles[req.params.id],...req.body};
    writeJson(PROFILES_FILE, profiles);
    res.json(profiles[req.params.id]);
  });

  app.post("/api/profiles/:id/load", (req,res) => {
    const profile = profiles[req.params.id];
    if (!profile) { res.status(404).json({error:"Not found"}); return; }
    cameras = JSON.parse(JSON.stringify(profile.cameras));
    session = JSON.parse(JSON.stringify(profile.session));
    lastProfileId = req.params.id;
    writeJson(CAMERAS_FILE, cameras);
    writeJson(SESSION_FILE, session);
    addLog("PROFILE",`Loaded: "${profile.name}"`,"success");
    res.json({profile,cameras,session});
  });

  app.delete("/api/profiles/:id", (req,res) => {
    const name = profiles[req.params.id]?.name||req.params.id;
    delete profiles[req.params.id];
    if (lastProfileId===req.params.id) lastProfileId=null;
    writeJson(PROFILES_FILE, profiles);
    addLog("PROFILE",`Deleted: "${name}"`,"warn");
    res.json({ok:true});
  });

  // ── Logs ──────────────────────────────────────────────────────────────────
  app.get("/api/logs", (_req,res) => res.json(logs.slice(0,50)));

  app.post("/api/settings/commit", (req,res) => {
    addLog("SETTINGS",`Committed: ${req.body.settingsTab||"unknown"}`);
    res.json({ok:true});
  });

  // ── Vite / static ─────────────────────────────────────────────────────────
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({ server:{middlewareMode:true}, appType:"spa" });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(),"dist");
    app.use(express.static(distPath));
    app.get("*",(_req,res)=>res.sendFile(path.join(distPath,"index.html")));
  }

  app.listen(PORT,"0.0.0.0",() => {
    console.log(`\n╔══════════════════════════════════════╗`);
    console.log(`║  DroidGrid Pro — http://localhost:${PORT} ║`);
    console.log(`║  Config: ${DATA_DIR.slice(0,26).padEnd(26)}  ║`);
    console.log(`╚══════════════════════════════════════╝\n`);
  });
}

startServer();
